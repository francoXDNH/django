function saludar() {

    // .value permite leer el valor de un campo de formulario
    let nombre = document.getElementById("nombre").value;

    // 1. Mostrar información en una ventana emergente
    alert(`Hola ${nombre}`);

    // 2. Mostrar información dentro de un input
    document.getElementById("resultado").value = `Hola, ${nombre}`;

    // 3. .innerText inserta texto visible dentro de una etiqueta
    document.getElementById("resultado2").innerText = `Hola, ${nombre}`;

    // 4. .innerHTML interpreta las etiquetas HTML del texto
    document.getElementById("resultado3").innerHTML = 
    `<p style="color: red;">Hola, ${nombre}</p>`;

    
    document.getElementById("resultado4").textContent = `Hola, ${nombre}`;

    // 6. document.write() escribe directo en el documento (ver advertencia arriba)
    // document.write(`Hola, ${nombre}`);

}

function registar(){
    let nombre = document.getElementById("nombre2").value;
    let programa = document.getElementById("programa2").value;
    
    alert(`El aprendiz ${nombre} esta inscrito en el ${programa}`);

    document.getElementById("resultado11").value=(`El aprendiz ${nombre} esta inscrito en el ${programa}`)
    document.getElementById("resultado22").innerText(`El aprendiz ${nombre} esta inscrito en el ${programa}`)
    document.getElementById("resultado33").innerHTML=
    <p style="color: red;">
    <strong>aprendiz</strong> ${nombre}<br></br>
    <strong>programa</strong> ${programa}
    </p>
    document.getElementById("resultado44").textContent=(`El aprendiz ${nombre} esta inscrito en el ${programa}`)
    console.log("Nombre:",nombre);
    console.log("programa:",programa);
}

function calcularOperaciones(){
    let valorUno = document.getElementById("valorUno").value;
    let valorDos = document.getElementById("valorDos").value;

    let suma = parseFloat(valorUno) + parseFloat(valorDos);
    let resta = parseFloat(valorUno) - parseFloat(valorDos);
    let multiplicacion = parseFloat(valorUno) * parseFloat(valorDos);
    let division = parseFloat(valorUno) / parseFloat(valorDos);

    document.getElementById("rSuma").innerText = `Suma: ${suma}`;
    document.getElementById("rResta").innerText = `Resta: ${resta}`;
    document.getElementById("rMultiplicacion").innerText = `Multiplicacion: ${multiplicacion}`;
    document.getElementById("rDivision").innerText = `Division: ${division}`;
}